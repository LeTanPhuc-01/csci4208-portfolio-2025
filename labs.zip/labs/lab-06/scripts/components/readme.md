# *dir:* **components**

This directory holds JavaScript functions that model an HTML component in the view.
Organize all such components within their own directory to improve reabability/browsability of the codebase. 
