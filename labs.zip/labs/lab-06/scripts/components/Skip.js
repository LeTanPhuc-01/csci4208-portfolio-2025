const Skip = () => (
    `<div>
        <button onclick='playGame()'> Skip </button>
    </div>`
);
export default Skip;