# Lab - 2 Reflection
> Breathe life into HTML page using the magic of **CSS**
## My reflection
This lab helped me understand the structure of a CSS file and how to use declarations, properties, and selectors to style web pages. I learned about Flexbox and Gridview for layout design and how they contribute to making responsive web pages that adapt to different screen sizes.