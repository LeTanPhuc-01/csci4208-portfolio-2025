# Lab - 3 Reflection
> Build a responsive portfolio using CSS framework **Bootstrap**
## My reflection
This lab helped me learn that there are CSS framework out there like Bootstrap and Tailwindcss which make life easier for Web Developer.